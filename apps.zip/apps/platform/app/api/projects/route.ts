import { NextResponse } from 'next/server';
import { safeParseProject } from '@segevision/renderer';
import { projectStore } from '../../../lib/storage';

// Project data is read from disk on every request; caching it would serve stale
// content straight after a save.
export const dynamic = 'force-dynamic';

export async function GET() {
  const projects = await projectStore.list();
  return NextResponse.json({ projects });
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const parsed = safeParseProject(body);

  if (!parsed.success) {
    return NextResponse.json(
      { error: 'הפרויקט שנשלח אינו תקין', issues: parsed.error.issues },
      { status: 400 },
    );
  }

  const created = await projectStore.create(parsed.data);
  return NextResponse.json({ project: created }, { status: 201 });
}
